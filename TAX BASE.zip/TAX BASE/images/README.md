Images used in documentation

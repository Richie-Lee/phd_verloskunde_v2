Data collection components:
- `bdo_XX_scrape.py` & `merge_scraped_files.py`: Webscraping code
- `data_visualised.xlsx`: Scraped data accessibly visualised (only for interpretation purposes)
- `bdo_XX_scrape.txt` & `bdo_scrape_full.txt`: Scraped data in txt file

